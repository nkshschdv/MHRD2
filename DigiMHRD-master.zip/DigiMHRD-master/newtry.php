<?php
$originalDate = "4-03-2017";
$newDate = date("Y-m-d", strtotime($originalDate));
echo $newDate;
?>