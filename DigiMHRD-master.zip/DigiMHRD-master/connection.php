<?php
 $m=mysqli_connect("localhost","root","");
 $db=mysqli_select_db($m,"hack");
<<<<<<< HEAD
<<<<<<< HEAD
?>
=======
?>

>>>>>>> de4ea9c4b906500c4a23025b14013ee70e400846
=======
 mysqli_query($m,"insert into try values('','2017-3-4')");
?>
>>>>>>> master_dpak
